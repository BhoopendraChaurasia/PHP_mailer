<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;

require 'vendor/autoload.php';

//PHPMailer Object


$mail = new PHPMailer(true); //Argument true in constructor enables exceptions
$mail->IsSMTP();
$mail->Host = "smtp.gmail.com";

// optional
// used only when SMTP requires authentication  
$mail->SMTPAuth = true;
$mail->Username = 'bchaurasia97@gmail.com';
$mail->Password = 'Bhoop97@';
// if you're using SSL
$mail->SMTPSecure = 'ssl';
// OR use TLS
$mail->SMTPSecure = 'tls';
//From email address and name
$mail->From = "bchaurasia97@gmail.com";
$mail->FromName = "Bhoopendra Chaurasia";

//To address and name
$mail->addAddress("bhoopendra727221@gmail.com", "Bhoopendra Chaurasia");
$mail->addAddress("bhoopendra.we2code@gmail.com"); //Recipient name is optional

//Address to which recipient will reply
$mail->addReplyTo("bchaurasia97@gmail.com", "Do not Reply!");

//CC and BCC
// $mail->addCC("cc@example.com");
// $mail->addBCC("bcc@example.com");

//Send HTML or Plain Text email
$mail->isHTML(true);

$mail->Subject = "This is testing mail";
$mail->Body = "<i>Mail recieve from $mail->FromName</i>";
$mail->AltBody = "This is the plain text version of the email content";

try {
    $mail->send();
    echo "Message has been sent successfully";
} catch (Exception $e) {
    echo "Mailer Error: " . $mail->ErrorInfo;
}



